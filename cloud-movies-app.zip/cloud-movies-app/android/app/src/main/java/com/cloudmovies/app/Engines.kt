package com.cloudmovies.app

import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.ZipInputStream

const val UA_MOBILE = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36"

/** پخش‌کننده‌ی ExoPlayer: همه‌ی کارهای پخش، ترک صدا، زیرنویس (داخلی و بیرونی) و لاگ. */
@OptIn(UnstableApi::class)
class ExoEngine(
    private val ctx: Context,
    private val view: PlayerView,
    private val l: Listener
) {
    interface Listener {
        fun onPlaying()
        fun onPaused()
        fun onBuffering(buffering: Boolean)
        fun onLength(ms: Long)
        fun onTime(ms: Long)
        fun onEnded()
        fun onError(msg: String)
        fun onLog(line: String)
        fun onTracksReady()
        fun onCues(visible: Boolean) {}
    }

    class Track(val id: Int, val name: String, val selected: Boolean, val supported: Boolean = true)

    private var p: ExoPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var lastLen = 0L
    private var gen = 0
    private var curUrl = ""
    private var savedApplied = false
    private var retries = 0
    private val prefs = ctx.getSharedPreferences("player", Context.MODE_PRIVATE)

    val isPlaying get() = p?.isPlaying == true
    val buffered get() = p?.bufferedPosition ?: 0L
    val length get() = p?.duration?.takeIf { it != C.TIME_UNSET } ?: 0L
    var time: Long
        get() = p?.currentPosition ?: 0L
        set(v) { p?.seekTo(v) }

    private val ticker = object : Runnable {
        override fun run() {
            val pl = p ?: return
            l.onTime(pl.currentPosition)
            val d = pl.duration
            if (d != C.TIME_UNSET && d > 0 && d != lastLen) { lastLen = d; l.onLength(d) }
            h.postDelayed(this, 500)
        }
    }

    private fun fmt(f: Format): String =
        "mime=" + f.sampleMimeType + " codecs=" + f.codecs + " lang=" + f.language + " label=" + f.label +
            " ch=" + f.channelCount + " hz=" + f.sampleRate + " size=" + f.width + "x" + f.height

    // ------------------------------------------------------------- شروع
    /** آدرس را (با زیرنویس‌های بیرونی که اول دانلود و تبدیل می‌شوند) پخش می‌کند. دوباره هم قابل‌صدازدن است (تغییر فایل/دوبله). */
    fun load(url: String, referer: String, startMs: Long, subs: JSONArray) {
        val my = ++gen
        curUrl = url
        savedApplied = false
        retries = 0
        l.onLog("LOAD " + url + " start=" + startMs / 1000 + "s subs=" + subs.length())
        if (subs.length() == 0) { begin(my, url, referer, startMs, emptyList()); return }
        Thread {
            val files = ArrayList<SubFile>()
            for (i in 0 until subs.length()) {
                val o = subs.optJSONObject(i) ?: continue
                val u = o.optString("url")
                if (u.isEmpty()) continue
                try {
                    val sf = fetchSubtitle(u, referer, i, o.optString("label", "زیرنویس"))
                    if (sf != null) files.add(sf)
                } catch (e: Throwable) { l.onLog("SUB FAIL " + u + " " + e) }
            }
            h.post { if (my == gen) begin(my, url, referer, startMs, files) }
        }.start()
    }

    private class SubFile(val file: File, val mime: String, val label: String)

    private fun fetchSubtitle(u: String, referer: String, idx: Int, label: String): SubFile? {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA_MOBILE)
        if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
        var raw = c.inputStream.use { it.readBytes() }
        var zipBad = false
        if (raw.size > 2 && raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()) {
            // زیرنویس زیپ‌شده: اولین فایل srt/vtt/ass داخلش
            zipBad = true
            ZipInputStream(ByteArrayInputStream(raw)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name.lowercase()
                    if (!e.isDirectory && (n.endsWith(".srt") || n.endsWith(".vtt") || n.endsWith(".ass") || n.endsWith(".ssa"))) { raw = z.readBytes(); zipBad = false; break }
                    e = z.nextEntry
                }
            }
        }
        if (zipBad) return null
        val text = decodeText(raw)
        if (text.isBlank() || text.trimStart().startsWith("<")) return null  // صفحه‌ی HTML/خطا
        val mime = when {
            text.trimStart().startsWith("WEBVTT") -> MimeTypes.TEXT_VTT
            text.contains("[Script Info]") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val ext = when (mime) { MimeTypes.TEXT_VTT -> "vtt"; MimeTypes.TEXT_SSA -> "ass"; else -> "srt" }
        val f = File(ctx.cacheDir, "sub_" + idx + "_" + System.currentTimeMillis() + "." + ext)
        f.writeText(text, Charsets.UTF_8)
        l.onLog("SUB OK " + mime + " chars=" + text.length)
        return SubFile(f, mime, label)
    }

    private fun decodeText(b: ByteArray): String {
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte()) return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        val start = if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte()) 3 else 0
        return try {
            Charsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(b, start, b.size - start)).toString()
        } catch (e: Throwable) {
            // زیرنویس‌های فارسیِ قدیمی: ویندوز-۱۲۵۶
            String(b, start, b.size - start, charset("windows-1256"))
        }
    }

    private fun begin(my: Int, url: String, referer: String, startMs: Long, subs: List<SubFile>) {
        if (my != gen) return
        val pl = p ?: create(referer)
        val b = MediaItem.Builder().setUri(Uri.parse(url))
        if (subs.isNotEmpty()) {
            b.setSubtitleConfigurations(subs.mapIndexed { i, s ->
                MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(s.file))
                    .setMimeType(s.mime)
                    .setLanguage("fa")
                    .setLabel(s.label)
                    .setSelectionFlags(if (i == 0) C.SELECTION_FLAG_DEFAULT else 0)
                    .build()
            })
        }
        pl.setPlaybackSpeed(rate)
        pl.setMediaItem(b.build(), if (startMs > 3000) startMs else 0L)
        pl.prepare()
        pl.playWhenReady = true
        h.removeCallbacks(ticker)
        h.post(ticker)
    }

    private fun create(referer: String): ExoPlayer {
        val ds = DefaultHttpDataSource.Factory()
            .setUserAgent(UA_MOBILE)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(15000)
        if (referer.isNotEmpty()) ds.setDefaultRequestProperties(mapOf("Referer" to referer))
        // بافر هوشمند: شروع سریع، حداکثر ۵۰ ثانیه جلوتر (مصرف اینترنت کنترل‌شده)
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(12000, 40000, 800, 2000).setPrioritizeTimeOverSizeThresholds(true).build()
        val rf = DefaultRenderersFactory(ctx).setEnableDecoderFallback(true)
        val pl = ExoPlayer.Builder(ctx, rf)
            .setMediaSourceFactory(DefaultMediaSourceFactory(ctx).setDataSourceFactory(ds))
            .setLoadControl(lc)
            // مدیریت خودکار فوکوس صدا (تماس/برنامه‌ی دیگر) و قطع شدن هدفون
            .setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p = pl
        // اگر فایل چند ترک صدا دارد، دوبله‌ی فارسی به‌طور پیش‌فرض انتخاب شود
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguages("fa", "fas", "per")
            .setPreferredTextLanguages("fa", "fas", "per")
            .build()
        view.player = pl
        view.useController = false
        view.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        view.setShutterBackgroundColor(Color.BLACK)
        view.subtitleView?.apply {
            setApplyEmbeddedStyles(false)
            setStyle(CaptionStyleCompat(Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null))
        }
        pl.addListener(object : Player.Listener {
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) { l.onCues(cueGroup.cues.isNotEmpty()) }
            override fun onPlaybackStateChanged(state: Int) { l.onLog("STATE " + state); push() }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { push() }
            override fun onPlayerError(error: PlaybackException) {
                l.onLog("ERROR " + error.errorCodeName + " " + (error.message ?: ""))
                // قطعی شبکه: تا ۴ بار با فاصله، از همان نقطه دوباره تلاش کن
                val io = error.errorCode in 2000..2999
                if (io && retries < 4) {
                    retries++
                    l.onLog("RETRY #" + retries)
                    l.onBuffering(true)
                    h.postDelayed({ try { p?.prepare() } catch (x: Throwable) { } }, 1500L * retries)
                    return
                }
                l.onError(error.errorCodeName)
            }
            override fun onTracksChanged(tracks: Tracks) {
                for (g in tracks.groups) for (i in 0 until g.length)
                    l.onLog("TRACK t=" + g.type + " " + fmt(g.getTrackFormat(i)) + " sup=" + g.isTrackSupported(i) + " sel=" + g.isTrackSelected(i))
                applySavedAudio()
                l.onTracksReady()
            }
        })
        pl.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                l.onLog("AUDIO DECODER " + decoderName)
            }
            override fun onVideoDecoderInitialized(eventTime: AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                l.onLog("VIDEO DECODER " + decoderName)
            }
        })
        return pl
    }

    private fun push() {
        val pl = p ?: return
        when (pl.playbackState) {
            Player.STATE_BUFFERING -> l.onBuffering(true)
            Player.STATE_READY -> { retries = 0; l.onBuffering(false) }
            Player.STATE_ENDED -> { l.onEnded(); return }
            else -> {}
        }
        if (pl.playbackState == Player.STATE_READY || pl.playbackState == Player.STATE_BUFFERING) {
            if (pl.playWhenReady) { if (pl.playbackState == Player.STATE_READY) l.onPlaying() } else l.onPaused()
        }
    }

    fun play() { p?.playWhenReady = true }
    fun pause() { p?.playWhenReady = false }
    private var rate = 1f
    fun setRate(r: Float) { rate = r; p?.setPlaybackSpeed(r) }
    fun setScale(i: Int) {
        view.resizeMode = when (i) {
            1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            2 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }

    // ---------------------------------------------------------- ترک‌ها
    private class Ref(val group: Tracks.Group, val idx: Int)

    private fun refs(type: Int): List<Ref> {
        val pl = p ?: return emptyList()
        val out = ArrayList<Ref>()
        for (g in pl.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) out.add(Ref(g, i))
        }
        return out
    }

    private fun label(r: Ref, n: Int, kind: String): String {
        val f = r.group.getTrackFormat(r.idx)
        val lang = f.language?.takeIf { it != "und" }?.let { Locale(it).displayLanguage }
        val parts = ArrayList<String>()
        parts.add(f.label ?: lang ?: "$kind $n")
        if (f.label != null && lang != null) parts.add(lang)
        if (type(r) == C.TRACK_TYPE_AUDIO) {
            f.sampleMimeType?.substringAfter('/')?.let { parts.add(it) }
            if (f.channelCount > 0) parts.add("${f.channelCount}ch")
        }
        return parts.joinToString(" · ")
    }

    private fun type(r: Ref) = r.group.type

    fun audioTracks(): List<Track> {
        val r = refs(C.TRACK_TYPE_AUDIO)
        return r.mapIndexed { i, x ->
            val sup = x.group.isTrackSupported(x.idx)
            Track(i, label(x, i + 1, "صدا") + (if (sup) "" else " (پشتیبانی نمی‌شود)"), x.group.isTrackSelected(x.idx), sup)
        }
    }

    fun setAudio(id: Int, save: Boolean = true) {
        val pl = p ?: return
        val r = refs(C.TRACK_TYPE_AUDIO).getOrNull(id) ?: return
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(r.group.mediaTrackGroup, r.idx)).build()
        if (save) prefs.edit().putInt(key(), id).apply()
        l.onLog("SELECT AUDIO #$id save=$save")
    }

    private fun key() = "audio:" + curUrl.substringBefore('?')

    private fun applySavedAudio() {
        if (savedApplied) return
        val n = refs(C.TRACK_TYPE_AUDIO).size
        if (n == 0) return
        savedApplied = true
        val idx = prefs.getInt(key(), -1)
        if (idx in 0 until n && n > 1) setAudio(idx, false)
    }

    fun subTracks(): List<Track> {
        val pl = p ?: return emptyList()
        val r = refs(C.TRACK_TYPE_TEXT)
        val off = pl.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || r.none { it.group.isTrackSelected(it.idx) }
        val out = ArrayList<Track>()
        out.add(Track(-1, "بدون زیرنویس", off))
        r.forEachIndexed { i, x -> out.add(Track(i, label(x, i + 1, "زیرنویس"), !off && x.group.isTrackSelected(x.idx), x.group.isTrackSupported(x.idx))) }
        return out
    }

    fun setSub(id: Int) {
        val pl = p ?: return
        val b = pl.trackSelectionParameters.buildUpon()
        if (id < 0) {
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        } else {
            val r = refs(C.TRACK_TYPE_TEXT).getOrNull(id) ?: return
            b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            b.setOverrideForType(TrackSelectionOverride(r.group.mediaTrackGroup, r.idx))
        }
        pl.trackSelectionParameters = b.build()
    }

    fun hasUnsupportedOnly(): Boolean {
        val a = refs(C.TRACK_TYPE_AUDIO)
        return a.isNotEmpty() && a.none { it.group.isTrackSupported(it.idx) }
    }

    fun release() {
        gen++
        h.removeCallbacksAndMessages(null)
        try { view.player = null; p?.release() } catch (e: Throwable) { }
        p = null
    }
}
