package com.cloudmovies.app

import android.app.Application
import org.json.JSONObject
import java.io.File
import java.net.InetAddress

/**
 * شروع سریع‌تر: همین لحظه‌ی اجرای برنامه (قبل از ساخته‌شدن صفحه) آدرس سرور را DNS-prefetch می‌کند.
 * گزارش کرش: اگر برنامه ناگهان بسته شود، متنش ذخیره می‌شود تا بار بعد قابل کپی و ارسال باشد.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            val prev = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try {
                    val sw = java.io.StringWriter()
                    e.printStackTrace(java.io.PrintWriter(sw))
                    File(filesDir, "crash.txt").writeText(
                        "زمان: " + java.util.Date() + "\nترد: " + t.name + "\n\n" + sw.toString().take(6000)
                    )
                } catch (x: Throwable) { }
                prev?.uncaughtException(t, e)
            }
        } catch (x: Throwable) { }
        Thread {
            try {
                val txt = assets.open("capacitor.config.json").bufferedReader().use { it.readText() }
                val url = JSONObject(txt).optJSONObject("server")?.optString("url") ?: ""
                val host = android.net.Uri.parse(url).host
                if (!host.isNullOrEmpty()) InetAddress.getAllByName(host)
            } catch (x: Throwable) { }
        }.start()
    }
}
