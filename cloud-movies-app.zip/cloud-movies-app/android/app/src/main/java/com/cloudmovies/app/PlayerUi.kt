package com.cloudmovies.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.PathParser

/** رنگ‌ها و اندازه‌ها از CSS پلیر وب (لیکوئید گلس). */
object Ui {
    val ACCENT = Color.parseColor("#3390EC")
    fun argb(a: Float, r: Int, g: Int, b: Int) = Color.argb((a * 255).toInt(), r, g, b)

    /** پس‌زمینه‌ی شیشه‌ای: رنگ نیمه‌شفاف + کادر نازک روشن */
    fun glass(fill: Int, border: Int, radiusDp: Float, density: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = radiusDp * density
        g.setStroke(Math.max(1, (density * 1f).toInt()), border)
        return g
    }
}

/** آیکن برداری با همان مسیرهای SVG وب (viewBox ۲۴). */
class IconView(ctx: Context) : View(ctx) {
    class Part(val d: String, val stroke: Boolean = false, val fill: Boolean = false, val flipX: Boolean = false)

    private var paths: List<Pair<Path, Part>> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var tint: Int = Color.WHITE

    fun set(vararg parts: Part) {
        // اگر مسیری قابل‌خواندن نبود، فقط همان آیکن نادیده گرفته می‌شود (برنامه کرش نمی‌کند)
        paths = parts.mapNotNull { pt ->
            try { Pair(PathParser.createPathFromPathData(pt.d), pt) } catch (e: Throwable) { null }
        }
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val s = Math.min(width, height) / 24f
        c.save()
        c.translate((width - 24 * s) / 2f, (height - 24 * s) / 2f)
        c.scale(s, s)
        for ((p, part) in paths) {
            paint.color = tint
            c.save()
            if (part.flipX) { c.translate(24f, 0f); c.scale(-1f, 1f) }
            if (part.stroke) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
            } else {
                paint.style = Paint.Style.FILL
            }
            c.drawPath(p, paint)
            c.restore()
        }
        c.restore()
    }

    companion object {
        val PLAY = Part("M8 5v14l11-7z", fill = true)
        val PAUSE = Part("M6 5h4v14H6zm8 0h4v14h-4z", fill = true)
        val BACK = Part("M15.5 4.5L8 12l7.5 7.5-1.4 1.4L5.2 12 14.1 3.1z", fill = true)
        val GEAR = Part("M19.4 13a7.5 7.5 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-1.7-1L14.9 3h-4l-.4 2.9a7.6 7.6 0 0 0-1.7 1l-2.4-1-2 3.4L6.4 11a7.5 7.5 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 1.7 1L11 21h4l.4-2.9a7.6 7.6 0 0 0 1.7-1l2.4 1 2-3.4zM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7z", fill = true)
        val RW = Part("M12 5V1L7 6l5 5V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z", fill = true)
        val FF = Part("M12 5V1L7 6l5 5V7a5 5 0 1 1-5 5H5a7 7 0 1 0 7-7z", fill = true, flipX = true)
        val LIST = Part("M4 6h16v2H4zm0 5h16v2H4zm0 5h10v2H4z", fill = true)
        val CLOCK = Part("M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 10.6l-4.2 2.5-.8-1.4L11 11.4V6h2z", fill = true)
        val FULL = Part("M4 9V4h5v2H6v3H4zm10-5h5v5h-2V6h-3V4zM4 15h2v3h3v2H4v-5zm14 3v-3h2v5h-5v-2h3z", fill = true)
        val LOCK1 = Part("M7.5 11h9a2.5 2.5 0 0 1 2.5 2.5v5a2.5 2.5 0 0 1-2.5 2.5h-9A2.5 2.5 0 0 1 5 18.5v-5A2.5 2.5 0 0 1 7.5 11z", stroke = true)
        val LOCK2 = Part("M8 11V8a4 4 0 0 1 8 0v3", stroke = true)
        val UNLOCK1 = Part("M7.7 10.5h8.6a3.2 3.2 0 0 1 3.2 3.2v4.1a3.2 3.2 0 0 1-3.2 3.2H7.7a3.2 3.2 0 0 1-3.2-3.2v-4.1a3.2 3.2 0 0 1 3.2-3.2z", stroke = true)
        val UNLOCK2 = Part("M8 10.5V8a4 4 0 0 1 7.6-1.7", stroke = true)
        val VOL1 = Part("M4 9v6h4l5 4V5L8 9z", stroke = true)
        val VOL2 = Part("M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12", stroke = true)
        val MUTE2 = Part("M17 9l5 6M22 9l-5 6", stroke = true)
        val SUB1 = Part("M6 5h12a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3z", stroke = true)
        val SUB2 = Part("M7 11h4M13 11h4M7 15h2M12 15h5", stroke = true)
        val MIC1 = Part("M12 3a3 3 0 0 0-3 3v6a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3z", stroke = true)
        val MIC2 = Part("M6 11a6 6 0 0 0 12 0M12 17v4", stroke = true)
        val ZOOM1 = Part("M4.5 11a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0-13 0", stroke = true)
        val ZOOM2 = Part("M16 16l5 5M11 8v6M8 11h6", stroke = true)
        val CLOSE = Part("M6 6l12 12M18 6L6 18", stroke = true)
        val CHECK = Part("M5 12.5l4.5 4.5L19 7.5", stroke = true)
    }
}

/** نوار پیشرفت/صدا هم‌شکل نوار وب: مسیر کم‌رنگ، بافر، پیشرفت سفید، دایره‌ی سفید با هاله. */
class GlassSeek(ctx: Context) : View(ctx) {
    interface Cb {
        fun onScrub(frac: Float, fromUser: Boolean)
        fun onStart()
        fun onCommit(frac: Float)
    }

    var cb: Cb? = null
    var progress = 0f
        private set
    var buffer = 0f
    var showBuffer = true
    private var dragging = false
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setProgress(f: Float) { if (!dragging) { progress = f.coerceIn(0f, 1f); invalidate() } }
    fun isDragging() = dragging

    override fun onDraw(c: Canvas) {
        val h = 4 * d
        val cy = height / 2f
        val pad = 10 * d
        val l = pad
        val r = width - pad
        val rect = RectF()
        p.style = Paint.Style.FILL
        p.color = Color.argb(56, 255, 255, 255)
        rect.set(l, cy - h / 2, r, cy + h / 2)
        c.drawRoundRect(rect, h / 2, h / 2, p)
        if (showBuffer && buffer > 0f) {
            p.color = Color.argb(70, 255, 255, 255)
            rect.set(l, cy - h / 2, l + (r - l) * buffer.coerceIn(0f, 1f), cy + h / 2)
            c.drawRoundRect(rect, h / 2, h / 2, p)
        }
        val x = l + (r - l) * progress
        p.color = Color.WHITE
        rect.set(l, cy - h / 2, x, cy + h / 2)
        c.drawRoundRect(rect, h / 2, h / 2, p)
        // هاله + دایره
        p.color = Color.argb(56, 255, 255, 255)
        c.drawCircle(x, cy, (if (dragging) 11 else 10) * d, p)
        p.color = Color.WHITE
        c.drawCircle(x, cy, (if (dragging) 7 else 6) * d, p)
    }

    private fun fracOf(e: MotionEvent): Float {
        val pad = 10 * d
        return ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                cb?.onStart()
                progress = fracOf(e); invalidate(); cb?.onScrub(progress, true)
            }
            MotionEvent.ACTION_MOVE -> { progress = fracOf(e); invalidate(); cb?.onScrub(progress, true) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                progress = fracOf(e); dragging = false; invalidate(); cb?.onCommit(progress)
            }
        }
        return true
    }
}
