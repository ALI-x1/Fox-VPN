package com.cloudmovies.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import com.getcapacitor.Bridge
import com.getcapacitor.BridgeWebViewClient
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import androidx.activity.OnBackPressedCallback
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private var exitDialog: AlertDialog? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    private fun bgColor(): Int = if (lightTheme) Color.parseColor("#F3F4F8") else Color.parseColor("#0B0D12")

    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(CloudPlayerPlugin::class.java)
        // آخرین تم را از حافظه می‌خوانیم تا از همان لحظه‌ی اول پس‌زمینه درست باشد (بدون پرش رنگ)
        lightTheme = getSharedPreferences("cm", Context.MODE_PRIVATE).getBoolean("light", false)
        window.setBackgroundDrawable(ColorDrawable(bgColor()))
        super.onCreate(savedInstanceState)
        try { bridge.setWebViewClient(CmClient(bridge)) } catch (e: Throwable) { }

        setupFullscreen()
        tuneWebView()
        setupBack()
        watchNetwork()
        ui.postDelayed({ showPreviousCrash() }, 1500)
    }

    // اگر دفعه‌ی قبل برنامه ناگهان بسته شده، گزارش را نشان بده تا بشود کپی و برای پشتیبانی فرستاد
    private fun showPreviousCrash() {
        try {
            val f = java.io.File(filesDir, "crash.txt")
            if (!f.exists()) return
            val txt = f.readText()
            f.delete()
            if (txt.isBlank()) return
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("برنامه بار قبل ناگهان بسته شد")
                .setMessage("اگر دوباره تکرار شد، گزارش را کپی کن و بفرست تا رفع شود.")
                .setPositiveButton("کپی گزارش") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", txt))
                }
                .setNegativeButton("بستن", null).show()
        } catch (e: Throwable) { }
    }

    // ------------------------------------------- تمام‌صفحه‌ی هم‌رنگ تم
    // صفحه زیر نوار بالا و پایین کشیده می‌شود؛ نوارها شفافند و رنگ تم برنامه را می‌گیرند.
    private var topInsetCss = 0
    private var bottomInsetCss = 0
    private var lightTheme = false

    private fun setupFullscreen() {
        getSharedPreferences("cm", Context.MODE_PRIVATE).let { topInsetCss = it.getInt("ti", 0); bottomInsetCss = it.getInt("bi", 0) }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) {
            val wlp = window.attributes
            wlp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = wlp
        }
        applyBarIcons()
        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { v, insets ->
            val sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val d = resources.displayMetrics.density
            val t = (sb.top / d).toInt()
            val b = if (ime > 0) 0 else (sb.bottom / d).toInt()
            findViewById<View>(android.R.id.content)?.setPadding(0, 0, 0, if (ime > 0) ime else 0)
            if (t != topInsetCss || b != bottomInsetCss) {
                topInsetCss = t; bottomInsetCss = b
                getSharedPreferences("cm", Context.MODE_PRIVATE).edit().putInt("ti", t).putInt("bi", b).apply()
                injectInsets()
            }
            ViewCompat.onApplyWindowInsets(v, insets)
        }
    }

    // آیکن‌های نوار وضعیت/ناوبری: تیره روی تم روشن، روشن روی تم تیره
    private fun applyBarIcons() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = lightTheme
        c.isAppearanceLightNavigationBars = lightTheme
    }

    private fun pollTheme() {
        val wv = bridge?.webView ?: return
        wv.evaluateJavascript("(function(){try{return document.documentElement.getAttribute('data-theme')||''}catch(e){return ''}})()") { r ->
            val light = r != null && r.contains("light")
            if (light != lightTheme) {
                lightTheme = light
                applyBarIcons()
                getSharedPreferences("cm", Context.MODE_PRIVATE).edit().putBoolean("light", light).apply()
            }
        }
    }

    private var coverSince = 0L
    // نگهبان: اگر پرده‌ی «در حال باز کردن پلیر» بیش از ۸ ثانیه مانده و پلیر بومی باز نیست، برش دار
    private fun coverWatch() {
        val wv = bridge?.webView ?: return
        wv.evaluateJavascript("(function(){try{return document.getElementById('nativeCover')?1:0}catch(e){return 0}})()") { r ->
            if (r == "1" && !PlayerActivity.active) {
                val now = System.currentTimeMillis()
                if (coverSince == 0L) coverSince = now
                else if (now - coverSince > 8000) {
                    coverSince = 0L
                    try { wv.evaluateJavascript("(function(){var c=document.getElementById('nativeCover');if(c)c.remove();window._forceWeb=true;})()", null) } catch (e: Throwable) { }
                }
            } else coverSince = 0L
        }
    }

    private val themeTask = object : Runnable {
        override fun run() { pollTheme(); try { coverWatch() } catch (e: Throwable) { }; ui.postDelayed(this, 1200) }
    }

    private fun insetsJs(): String = "(function(){try{var r=document.documentElement;if(!r)return 0;" +
        "r.style.setProperty('--tg-top','${topInsetCss}px');r.style.setProperty('--tg-bottom','${bottomInsetCss}px');" +
        "r.classList.add('cm_app');return 1}catch(e){return 0}})()"

    // صفحه تا لحظه‌ای که فاصله‌ها اعمال شوند پنهان می‌ماند؛ بعد نرم ظاهر می‌شود (بدون پرش و کم‌وزیاد شدن)
    private fun reveal(v: View) {
        if (v.alpha >= 1f) return
        v.animate().cancel()
        v.animate().alpha(1f).setDuration(140).start()
    }

    private fun injectInsets() {
        val js = insetsJs()
        val wv = bridge?.webView ?: return
        for (d in longArrayOf(0, 400, 1200, 2500, 5000)) {
            ui.postDelayed({ try { wv.evaluateJavascript(js, null) } catch (e: Throwable) { } }, d)
        }
    }

    // ------------------------------------------------------ روانی و سرعت
    // کلاینت وب‌ویو: بعد از هر لود، فاصله‌ها را می‌دهد؛ اگر پروسه‌ی وب‌ویو کرش کرد، به‌جای بسته شدن برنامه دوباره می‌سازد
    private inner class CmClient(b: Bridge) : BridgeWebViewClient(b) {
        override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            view.animate().cancel()
            view.alpha = 0f
            try { view.evaluateJavascript(insetsJs(), null) } catch (e: Throwable) { }
            ui.postDelayed({ reveal(view) }, 1800)   // شبکه‌ی مطمئن: هیچ‌وقت پنهان نماند
        }
        override fun onPageFinished(view: WebView, url: String?) {
            super.onPageFinished(view, url)
            injectInsets()
            pollTheme()
            reveal(view)
        }
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            return ApiCache.handle(applicationContext, request) ?: super.shouldInterceptRequest(view, request)
        }
        // پرده‌ی مشکی از همان اولین لحظه‌ی باز شدن صفحه‌ی پلیر، تا پلیر وب دیده نشود
        override fun onPageCommitVisible(view: WebView, url: String?) {
            super.onPageCommitVisible(view, url)
            try { view.evaluateJavascript(insetsJs()) { reveal(view) } } catch (e: Throwable) { reveal(view) }
            if (url != null && url.contains("/player?") && !url.contains("trailer=")) {
                try {
                    view.evaluateJavascript("(function(){try{if(!window.Capacitor||window.__cmCoverDone||document.getElementById('nativeCover')||document.querySelector('.selector_overlay.show')||document.querySelector('#fallback.show'))return;var c=document.createElement('div');c.id='nativeCover';c.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:#000;display:flex;align-items:center;justify-content:center;color:#8b8f99;font:14px sans-serif';c.textContent='در حال باز کردن پلیر…';(document.body||document.documentElement).appendChild(c)}catch(e){}})()", null)
                } catch (e: Throwable) { }
            }
        }
        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            ui.post { try { recreate() } catch (e: Throwable) { } }
            return true
        }
    }

    private fun tuneWebView() {
        val wv = bridge?.webView ?: return
        val s = wv.settings
        s.domStorageEnabled = true
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.textZoom = 100
        s.loadsImagesAutomatically = true
        s.setGeolocationEnabled(false)
        if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = false
        wv.setDownloadListener { u, _, _, _, _ ->
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) { }
        }
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        wv.setBackgroundColor(bgColor())
        wv.isLongClickable = false
        wv.setOnLongClickListener { true }
    }

    // ------------------------------------------------- دکمه‌ی بازگشت (تأیید)
    private fun setupBack() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = bridge?.webView
                if (wv == null) { confirmExit(); return }
                // 1 = مینی‌اپ خودش یک مرحله برگشت؛ 0 = در صفحه‌ی اصلی است؛ -1 = صفحه‌ی دیگری (مثل پلیر وب) که قلاب ندارد
                val js = "(function(){try{return window.__cmBack?window.__cmBack():-1}catch(e){return -1}})()"
                wv.evaluateJavascript(js) { r ->
                    val v = r?.trim()
                    when {
                        v == "1" -> {}
                        v == "0" -> confirmExit()
                        wv.canGoBack() -> wv.goBack()
                        else -> confirmExit()
                    }
                }
            }
        })
    }

    private fun confirmExit() {
        if (exitDialog?.isShowing == true) return
        val d = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("خروج از Cloud Movies؟")
            .setMessage("مطمئنی می‌خوای از برنامه خارج بشی؟")
            .setNegativeButton("ماندن") { dlg, _ -> dlg.dismiss() }
            .setPositiveButton("خروج") { _, _ -> finishAffinity() }
            .create()
                d.window?.decorView?.layoutDirection = View.LAYOUT_DIRECTION_RTL
        exitDialog = d
        d.show()
    }

    // ------------------------------------------ بازگشت خودکار بعد از قطعی نت
    private fun watchNetwork() {
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    ui.post {
                        val wv = bridge?.webView ?: return@post
                        val u = wv.url ?: ""
                        if (u.contains("offline.html")) {
                            wv.evaluateJavascript(
                                "(function(){try{var b=document.getElementById('retry')||document.querySelector('button');if(b)b.click();else location.reload()}catch(e){}})()",
                                null
                            )
                        }
                    }
                }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (e: Throwable) { }
    }

    override fun onResume() {
        super.onResume()
        injectInsets()
        ui.removeCallbacks(themeTask)
        ui.post(themeTask)
    }

    override fun onPause() {
        ui.removeCallbacks(themeTask)
        super.onPause()
    }

    override fun onDestroy() {
        try {
            netCb?.let { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) }
        } catch (e: Throwable) { }
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
