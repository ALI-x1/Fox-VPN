package com.cloudmovies.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import kotlin.math.abs

/**
 * پلیر بومی تمام‌صفحه با ExoPlayer: شروع سریع، دیکد سخت‌افزاری، ترک صدا/دوبله و زیرنویس.
 * کنترل‌ها: لمس = نمایش/مخفی، دوبار لمس چپ/راست = ‎∓۱۰ ثانیه، وسط = پخش/توقف،
 * کشیدن عمودی چپ = روشنایی، راست = صدا.
 */
@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity(), ExoEngine.Listener {

    private var engine: ExoEngine? = null
    private var variants: JSONArray = JSONArray()
    private var curVariant = 0
    private val logBuf = ArrayDeque<String>()
    private val t0 = android.os.SystemClock.elapsedRealtime()
    private lateinit var exoView: PlayerView
    private var mediaUrl = ""
    private var mediaReferer = ""
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var controls: FrameLayout
    private lateinit var titleView: TextView
    private lateinit var playBtnBig: android.widget.FrameLayout
    private lateinit var playIconBig: IconView
    private lateinit var playIconMini: IconView
    private lateinit var seek: GlassSeek
    private lateinit var volSeek: GlassSeek
    private lateinit var volIcon: IconView
    private lateinit var qualityLabel: TextView
    private lateinit var speedLabel: TextView
    private lateinit var lockLayer: android.widget.FrameLayout
    private lateinit var unlockBtn: android.widget.FrameLayout
    private lateinit var zoomPill: LinearLayout
    private lateinit var zoomText: TextView
    private lateinit var scrubBubble: TextView
    private var locked = false
    private var boost = false
    companion object { @Volatile var active = false }
    private lateinit var loader: FrameLayout
    private lateinit var skipBtn: TextView
    private lateinit var nextCard: LinearLayout
    private lateinit var nextTxt: TextView
    private var hasNext = false
    private var noNext = false
    private var skipDone = false
    private var nextLeft = 0
    private var resumeKey = ""
    private var lastSaveAt = 0L
    @Volatile private var cueOn = false
    private var subDragCand = false
    private var subDragging = false
    private var subStartY = 0f
    private var subStartBottom = 0f
    private var pinchSub = false
    private var sfLeft: TextView? = null
    private var sfRight: TextView? = null
    private var loaderGone = false
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var subSize = 0.055f
    private var subBottom = 0.08f
    private var titleName = ""
    private var yearChip = ""
    private var epChip = ""
    private lateinit var curView: TextView
    private lateinit var totView: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var toast: TextView
    private lateinit var audioManager: AudioManager

    private var resumeMs = 0L
    private var subs: JSONArray = JSONArray()
    private var lastPos = 0L
    private var lastLen = 0L
    private var ended = false
    private var errorMsg = ""
    private var controlsShown = true
    private var dragging = false
    private var userPaused = false
    private var speedIdx = 2
    private var scaleIdx = 0
    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    private val hideTask = Runnable { setControls(false) }
    private val toastTask = Runnable { toast.visibility = View.GONE }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val cutLp = window.attributes
            cutLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = cutLp
        }
        active = true
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        val url = intent.getStringExtra("url") ?: ""
        val title = intent.getStringExtra("title") ?: ""
        val referer = intent.getStringExtra("referer") ?: ""
        titleName = title
        yearChip = intent.getStringExtra("year") ?: ""
        epChip = intent.getStringExtra("ep") ?: ""
        val pf = getSharedPreferences("player", MODE_PRIVATE)
        subSize = pf.getFloat("sub_size", 0.055f)
        subBottom = pf.getFloat("sub_bottom", 0.08f)
        speedIdx = pf.getInt("speed", 2).coerceIn(0, speeds.size - 1)
        scaleIdx = pf.getInt("scale", 0).coerceIn(0, 2)
        resumeMs = intent.getLongExtra("position", 0L)
        hasNext = intent.getBooleanExtra("hasNext", false)
        resumeKey = "res:" + url.substringBefore('?')
        // ادامه‌ی محلی: اگر اپ وسط پخش بسته شده بود، از آخرین جای ذخیره‌شده ادامه بده
        val savedPos = pf.getLong(resumeKey, 0L)
        if (savedPos > resumeMs) resumeMs = savedPos
        lastPos = resumeMs
        try { subs = JSONArray(intent.getStringExtra("subs") ?: "[]") } catch (e: Exception) { subs = JSONArray() }

        buildUi(title)
        hideSystemBars()

        if (url.isEmpty()) {
            errorMsg = "آدرس پخش خالی است"
            finish()
            return
        }

        mediaUrl = url
        mediaReferer = referer
        try { variants = JSONArray(intent.getStringExtra("variants") ?: "[]") } catch (e: Exception) { variants = JSONArray() }
        for (i in 0 until variants.length()) if (variants.optJSONObject(i)?.optString("url") == url) curVariant = i
        engine = ExoEngine(this, exoView, this)
        engine?.load(url, referer, resumeMs, subs)
        applySubStyle()
        refreshQualityLabel()
        engine?.setRate(speeds[speedIdx])
        engine?.setScale(scaleIdx)
        spinner.visibility = View.VISIBLE
        scheduleHide()
    }

    // ---------------------------------------------------------------- UI (هم‌شکل پلیر وب)
    private val dens get() = resources.displayMetrics.density

    private fun glassCircle(sizeDp: Int, fill: Int, border: Int): android.widget.FrameLayout {
        val f = android.widget.FrameLayout(this)
        f.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(fill)
        g.setStroke(dp(1), border)
        f.background = g
        return f
    }

    private fun icon(vararg parts: IconView.Part, sizeDp: Int): IconView {
        val v = IconView(this)
        v.set(*parts)
        v.layoutParams = android.widget.FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER)
        return v
    }

    private fun pressable(v: View, onClick: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener { if (!locked) { onClick(); scheduleHide() } }
        v.setOnTouchListener { vv, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> vv.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> vv.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    // دکمه‌ی گرد بالا (برگشت/قفل/تنظیمات): شیشه‌ای ۳۸dp
    private fun topBtn(vararg parts: IconView.Part, onClick: () -> Unit): android.widget.FrameLayout {
        val f = glassCircle(38, Color.argb(46, 255, 255, 255), Color.argb(66, 255, 255, 255))
        f.addView(icon(*parts, sizeDp = 20))
        pressable(f, onClick)
        return f
    }

    // دکمه‌ی پایین (مثل .bottombtn): آیکن + برچسب اختیاری
    private fun bottomBtn(vararg parts: IconView.Part, label: TextView? = null, onClick: () -> Unit): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER
        l.setPadding(dp(8), 0, dp(8), 0)
        l.minimumHeight = dp(36)
        l.minimumWidth = dp(36)
        l.addView(icon(*parts, sizeDp = 20).also { it.layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)) })
        if (label != null) {
            label.setTextColor(Color.argb(217, 255, 255, 255))
            label.textSize = 13f
            label.setPadding(dp(5), 0, 0, 0)
            l.addView(label)
        }
        pressable(l, onClick)
        return l
    }

    private fun buildUi(title: String) {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        setContentView(root)

        exoView = PlayerView(this)
        root.addView(exoView, FrameLayout.LayoutParams(-1, -1))

        // لایه‌ی کنترل‌ها (خودش لمس را نمی‌گیرد تا ژست‌ها به root برسند)
        controls = FrameLayout(this)
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        // گرادیان بالا و پایین مثل وب
        val gTop = View(this)
        gTop.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(140, 0, 0, 0), Color.TRANSPARENT))
        controls.addView(gTop, FrameLayout.LayoutParams(-1, dp(110), Gravity.TOP))
        val gBot = View(this)
        gBot.background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(180, 0, 0, 0), Color.TRANSPARENT))
        controls.addView(gBot, FrameLayout.LayoutParams(-1, dp(170), Gravity.BOTTOM))

        // ===== نوار بالا (راست‌چین مثل وب): برگشت + عنوان | قفل + تنظیمات =====
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.layoutDirection = View.LAYOUT_DIRECTION_RTL
        top.setPadding(dp(28), dp(12), dp(28), dp(12))
        val back = topBtn(IconView.BACK) { onBackTap() }
        top.addView(back)
        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.layoutDirection = View.LAYOUT_DIRECTION_RTL
        pill.setPadding(dp(16), dp(8), dp(16), dp(8))
        pill.background = Ui.glass(Color.argb(46, 255, 255, 255), Color.argb(46, 255, 255, 255), 999f, dens)
        titleView = TextView(this)
        titleView.text = title
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 14f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        pill.addView(titleView, LinearLayout.LayoutParams(-2, -2))
        fun chipView(t: String, bg: Int): TextView {
            val c = TextView(this)
            c.text = t
            c.setTextColor(Color.WHITE)
            c.textSize = 11f
            c.typeface = Typeface.DEFAULT_BOLD
            c.layoutDirection = View.LAYOUT_DIRECTION_LTR
            c.setPadding(dp(8), dp(2), dp(8), dp(2))
            c.background = Ui.glass(bg, Color.TRANSPARENT, 999f, dens).also { it.setStroke(0, Color.TRANSPARENT) }
            return c
        }
        if (yearChip.isNotEmpty()) pill.addView(chipView(yearChip, Color.argb(41, 255, 255, 255)), LinearLayout.LayoutParams(-2, -2).also { it.marginEnd = dp(0); it.marginStart = dp(8) })
        if (epChip.isNotEmpty()) pill.addView(chipView(epChip, Color.argb(140, 51, 144, 236)), LinearLayout.LayoutParams(-2, -2).also { it.marginStart = dp(8) })
        top.addView(pill, LinearLayout.LayoutParams(-2, -2).also { it.marginStart = dp(10) })
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val lockBtn = topBtn(IconView.LOCK1, IconView.LOCK2) { setLocked(true) }
        top.addView(lockBtn, LinearLayout.LayoutParams(dp(38), dp(38)).also { it.marginStart = dp(10) })
        val gear = topBtn(IconView.GEAR) { openSettings() }
        top.addView(gear, LinearLayout.LayoutParams(dp(38), dp(38)).also { it.marginStart = dp(10) })
        controls.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ===== وسط: ‎-۱۰ / پخش / ‎+۱۰ =====
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.HORIZONTAL
        mid.gravity = Gravity.CENTER
        mid.layoutDirection = View.LAYOUT_DIRECTION_LTR
        val bwd = glassCircle(46, Color.argb(36, 255, 255, 255), Color.argb(56, 255, 255, 255))
        val rwIc = icon(IconView.RW, sizeDp = 22)
        bwd.addView(rwIc); pressable(bwd) { seekBy(-10_000); seekFlash(false); ring(bwd); spin(rwIc, -360f) }
        playBtnBig = glassCircle(70, Color.argb(36, 255, 255, 255), Color.argb(56, 255, 255, 255))
        playIconBig = icon(IconView.PAUSE, sizeDp = 30)
        playBtnBig.addView(playIconBig); pressable(playBtnBig) { ring(playBtnBig); togglePlay() }
        val fwd = glassCircle(46, Color.argb(36, 255, 255, 255), Color.argb(56, 255, 255, 255))
        val ffIc = icon(IconView.FF, sizeDp = 22)
        fwd.addView(ffIc); pressable(fwd) { seekBy(10_000); seekFlash(true); ring(fwd); spin(ffIc, 360f) }
        val gap = dp(120)
        mid.addView(bwd)
        mid.addView(playBtnBig, LinearLayout.LayoutParams(dp(70), dp(70)).also { it.setMargins(gap, 0, gap, 0) })
        mid.addView(fwd)
        controls.addView(mid, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ===== پایین: پنل شیشه‌ای =====
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.layoutDirection = View.LAYOUT_DIRECTION_LTR
        panel.setPadding(dp(14), dp(8), dp(14), dp(6))
        panel.background = Ui.glass(Color.argb(120, 14, 16, 24), Color.argb(36, 255, 255, 255), 20f, dens)

        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        timeRow.gravity = Gravity.CENTER_VERTICAL
        curView = TextView(this); curView.setTextColor(Color.argb(217, 255, 255, 255)); curView.textSize = 12f; curView.text = "00:00"
        totView = TextView(this); totView.setTextColor(Color.argb(217, 255, 255, 255)); totView.textSize = 12f; totView.text = "00:00"
        curView.setShadowLayer(3f, 0f, 1f, Color.argb(100, 0, 0, 0)); totView.setShadowLayer(3f, 0f, 1f, Color.argb(100, 0, 0, 0))
        seek = GlassSeek(this)
        seek.cb = object : GlassSeek.Cb {
            override fun onScrub(frac: Float, fromUser: Boolean) {
                if (lastLen > 0) {
                    curView.text = fmt((lastLen * frac).toLong())
                    val d = (lastLen * frac).toLong() - lastPos
                    scrubBubble.text = fmt((lastLen * frac).toLong()) + "   " + (if (d >= 0) "+" else "−") + fmt(Math.abs(d))
                    scrubBubble.visibility = View.VISIBLE
                }
            }
            override fun onStart() { dragging = true; ui.removeCallbacks(hideTask) }
            override fun onCommit(frac: Float) {
                dragging = false
                scrubBubble.visibility = View.GONE
                if (lastLen > 0) engine?.time = (lastLen * frac).toLong()
                scheduleHide()
            }
        }
        timeRow.addView(curView)
        timeRow.addView(seek, LinearLayout.LayoutParams(0, dp(30), 1f).also { it.setMargins(dp(4), 0, dp(4), 0) })
        timeRow.addView(totView)
        panel.addView(timeRow, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        // چپ: پخش + صدا
        val miniPlay = bottomBtn(IconView.PLAY) { togglePlay() }
        playIconMini = (miniPlay.getChildAt(0) as IconView)
        row.addView(miniPlay)
        volIcon = IconView(this); volIcon.set(IconView.VOL1, IconView.VOL2)
        val volBtn = LinearLayout(this)
        volBtn.gravity = Gravity.CENTER
        volBtn.setPadding(dp(8), 0, dp(8), 0)
        volBtn.addView(volIcon, LinearLayout.LayoutParams(dp(20), dp(20)))
        pressable(volBtn) { toggleMute() }
        row.addView(volBtn, LinearLayout.LayoutParams(-2, dp(36)))
        volSeek = GlassSeek(this)
        volSeek.showBuffer = false
        volSeek.cb = object : GlassSeek.Cb {
            override fun onScrub(frac: Float, fromUser: Boolean) {
                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(frac * max), 0)
                updateVolIcon(frac)
            }
            override fun onStart() { ui.removeCallbacks(hideTask) }
            override fun onCommit(frac: Float) { scheduleHide() }
        }
        row.addView(volSeek, LinearLayout.LayoutParams(dp(110), dp(30)))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        // راست: صدا، زیرنویس، کیفیت، سرعت، تمام‌صفحه
        row.addView(bottomBtn(IconView.MIC1, IconView.MIC2) { pickAudio() })
        row.addView(bottomBtn(IconView.SUB1, IconView.SUB2) { pickSubtitle() })
        qualityLabel = TextView(this); qualityLabel.text = "--"
        row.addView(bottomBtn(IconView.LIST, label = qualityLabel) { pickQuality() })
        speedLabel = TextView(this); speedLabel.text = "1x"
        row.addView(bottomBtn(IconView.CLOCK, label = speedLabel) { pickSpeed() })
        row.addView(bottomBtn(IconView.FULL) { cycleScale() })
        panel.addView(row, LinearLayout.LayoutParams(-1, -2))
        controls.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).also { it.setMargins(dp(28), 0, dp(28), dp(8)) })

        // حباب زمان هنگام کشیدن نوار
        scrubBubble = TextView(this)
        scrubBubble.setTextColor(Color.WHITE); scrubBubble.textSize = 14f; scrubBubble.typeface = Typeface.DEFAULT_BOLD
        scrubBubble.setPadding(dp(14), dp(8), dp(14), dp(8))
        scrubBubble.background = Ui.glass(Color.argb(190, 18, 20, 28), Color.argb(46, 255, 255, 255), 14f, dens)
        scrubBubble.visibility = View.GONE
        root.addView(scrubBubble, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).also { it.bottomMargin = dp(120) })

        // قفل: فقط دکمه‌ی باز کردن
        lockLayer = android.widget.FrameLayout(this)
        lockLayer.visibility = View.GONE
        unlockBtn = glassCircle(46, Color.argb(60, 255, 255, 255), Color.argb(80, 255, 255, 255))
        unlockBtn.addView(icon(IconView.UNLOCK1, IconView.UNLOCK2, sizeDp = 22))
        unlockBtn.setOnClickListener { setLocked(false) }
        unlockBtn.visibility = View.GONE
        root.addView(unlockBtn, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.START or Gravity.CENTER_VERTICAL).also { it.marginStart = dp(34) })

        // نشانگر زوم (مثل وب): ۱۰۰٪ + ذره‌بین، لمس = بازنشانی
        zoomPill = LinearLayout(this)
        zoomPill.orientation = LinearLayout.HORIZONTAL
        zoomPill.gravity = Gravity.CENTER
        zoomPill.setPadding(dp(16), dp(10), dp(16), dp(10))
        zoomPill.background = Ui.glass(Color.argb(150, 40, 42, 50), Color.argb(36, 255, 255, 255), 999f, dens)
        zoomText = TextView(this); zoomText.setTextColor(Color.WHITE); zoomText.textSize = 14f; zoomText.text = "100٪"
        zoomPill.addView(zoomText)
        zoomPill.addView(icon(IconView.ZOOM1, IconView.ZOOM2, sizeDp = 18).also { it.layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).also { lp -> lp.marginStart = dp(8) } })
        zoomPill.visibility = View.GONE
        zoomPill.setOnClickListener { resetZoom() }
        root.addView(zoomPill, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).also { it.bottomMargin = dp(96) })

        spinner = ProgressBar(this)
        root.addView(spinner, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))

        toast = TextView(this)
        toast.setTextColor(Color.WHITE)
        toast.textSize = 18f
        toast.typeface = Typeface.DEFAULT_BOLD
        toast.gravity = Gravity.CENTER
        toast.setPadding(dp(22), dp(12), dp(22), dp(12))
        toast.background = Ui.glass(Color.argb(190, 18, 20, 28), Color.argb(46, 255, 255, 255), 22f, dens)
        toast.visibility = View.GONE
        root.addView(toast, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).also { it.topMargin = dp(70) })

        // دکمه‌ی رد کردن تیتراژ (سریال)
        skipBtn = TextView(this)
        skipBtn.text = "رد کردن تیتراژ  ⏭"
        skipBtn.setTextColor(Color.WHITE)
        skipBtn.textSize = 14f
        skipBtn.typeface = Typeface.DEFAULT_BOLD
        skipBtn.setPadding(dp(20), dp(11), dp(20), dp(11))
        skipBtn.background = Ui.glass(Color.argb(200, 18, 20, 28), Color.argb(70, 255, 255, 255), 22f, dens)
        skipBtn.visibility = View.GONE
        skipBtn.setOnClickListener { seekBy(85_000); skipDone = true; skipBtn.visibility = View.GONE; flash("۸۵ ثانیه جلو رفت") }
        root.addView(skipBtn, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).also { it.setMargins(0, 0, dp(28), dp(130)) })

        // کارت «قسمت بعدی» با شمارش معکوس
        nextCard = LinearLayout(this)
        nextCard.orientation = LinearLayout.VERTICAL
        nextCard.gravity = Gravity.CENTER
        nextCard.setPadding(dp(22), dp(16), dp(22), dp(16))
        nextCard.background = Ui.glass(Color.argb(215, 18, 20, 28), Color.argb(70, 255, 255, 255), 24f, dens)
        nextCard.visibility = View.GONE
        nextTxt = TextView(this)
        nextTxt.setTextColor(Color.WHITE); nextTxt.textSize = 15f; nextTxt.typeface = Typeface.DEFAULT_BOLD
        nextCard.addView(nextTxt)
        val nrow = LinearLayout(this)
        nrow.orientation = LinearLayout.HORIZONTAL
        nrow.gravity = Gravity.CENTER
        nrow.setPadding(0, dp(12), 0, 0)
        val nNow = TextView(this)
        nNow.text = "پخش حالا"; nNow.setTextColor(Color.WHITE); nNow.textSize = 14f; nNow.typeface = Typeface.DEFAULT_BOLD
        nNow.setPadding(dp(18), dp(9), dp(18), dp(9))
        nNow.background = Ui.glass(Ui.ACCENT, Color.TRANSPARENT, 18f, dens)
        nNow.setOnClickListener { ui.removeCallbacks(nextTick); ended = true; finish() }
        val nCan = TextView(this)
        nCan.text = "لغو"; nCan.setTextColor(Color.WHITE); nCan.textSize = 14f
        nCan.setPadding(dp(18), dp(9), dp(18), dp(9))
        nCan.background = Ui.glass(Color.argb(60, 255, 255, 255), Color.TRANSPARENT, 18f, dens)
        nCan.setOnClickListener { cancelNext() }
        nrow.addView(nNow)
        nrow.addView(nCan, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = dp(10) })
        nextCard.addView(nrow)
        root.addView(nextCard, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).also { it.setMargins(0, 0, dp(28), dp(130)) })

        // لودینگ پلیر: فقط پوستر محو (بلور) + یک نوار باریک متحرک؛ بدون لوگو و بدون نام
        loader = FrameLayout(this)
        loader.setBackgroundColor(Color.BLACK)
        loader.isClickable = true
        val posterUrl = intent.getStringExtra("poster") ?: ""
        if (posterUrl.startsWith("http")) {
            Thread {
                try {
                    val c = java.net.URL(posterUrl).openConnection() as java.net.HttpURLConnection
                    c.connectTimeout = 6000; c.readTimeout = 8000
                    c.setRequestProperty("User-Agent", UA_MOBILE)
                    val raw = try { c.inputStream.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 }) } } finally { c.disconnect() }
                    if (raw != null) {
                        val w = 72
                        val h = (w.toFloat() * raw.height / raw.width).toInt().coerceIn(48, 160)
                        val sm = boxBlur(Bitmap.createScaledBitmap(raw, w, h, true), 4, 3)
                        ui.post {
                            if (loaderGone || isFinishing) return@post
                            val bg = android.widget.ImageView(this)
                            bg.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                            bg.setImageBitmap(sm)
                            bg.alpha = 0f
                            loader.addView(bg, 0, FrameLayout.LayoutParams(-1, -1))
                            bg.animate().alpha(0.8f).setDuration(400).start()
                        }
                    }
                } catch (e: Throwable) { }
            }.start()
        }
        val track = FrameLayout(this)
        val tbg = android.graphics.drawable.GradientDrawable()
        tbg.cornerRadius = dp(3).toFloat()
        tbg.setColor(Color.argb(60, 255, 255, 255))
        track.background = tbg
        val thumb = View(this)
        val thg = android.graphics.drawable.GradientDrawable()
        thg.cornerRadius = dp(3).toFloat()
        thg.setColor(Color.WHITE)
        thumb.background = thg
        track.addView(thumb, FrameLayout.LayoutParams(dp(44), dp(3)))
        loader.addView(track, FrameLayout.LayoutParams(dp(120), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(56) })
        root.addView(loader, FrameLayout.LayoutParams(-1, -1))
        val slide = android.animation.ObjectAnimator.ofFloat(thumb, "translationX", 0f, dp(76).toFloat())
        slide.duration = 750
        slide.interpolator = android.view.animation.AccelerateDecelerateInterpolator()
        slide.repeatMode = android.animation.ValueAnimator.REVERSE
        slide.repeatCount = android.animation.ValueAnimator.INFINITE
        slide.start()
        loader.tag = slide

        // ژست‌ها: لمس، دوبار لمس، کشیدن (روشنایی/صدا)، دو انگشت (زوم و جابه‌جایی)
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean { scrollMode = 0; hSeeking = false; hStartPos = lastPos; return true }
            override fun onLongPress(e: MotionEvent) {
                if (locked || zoom > 1.02f) return
                if (e.x < root.width / 2f) {
                    // نیمه‌ی چپ: عقب‌رفتن پیوسته ۲x (ExoPlayer سرعت منفی ندارد؛ با پرش‌های کوچک شبیه‌سازی می‌شود)
                    rewinding = true
                    rwWasPlaying = engine?.isPlaying == true
                    engine?.pause()
                    ui.post(rwTick)
                } else {
                    boost = true
                    engine?.setRate(2f)
                    flash("▶▶  سرعت ۲x (تا وقتی نگه داشته‌ای)")
                }
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) { showUnlockTemporarily(); return true }
                setControls(!controlsShown); return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = root.width.toFloat()
                when {
                    e.x < w * 0.35f -> { seekBy(-10_000); seekFlash(false) }
                    e.x > w * 0.65f -> { seekBy(10_000); seekFlash(true) }
                    else -> togglePlay()
                }
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || e2.pointerCount > 1) return false
                if (zoom > 1.02f) { panX -= dx; panY -= dy; applyZoom(); return true }
                if (scrollMode == 0) scrollMode = if (abs(e2.x - e1.x) > abs(e2.y - e1.y)) 2 else 1
                if (scrollMode == 2) {
                    // کشیدن افقی = جلو/عقب بردن (مثل MX): تمام عرض صفحه ≈ ۹۰ ثانیه
                    val len = lastLen
                    var t = hStartPos + ((e2.x - e1.x) / root.width.toFloat() * 90_000f).toLong()
                    t = t.coerceAtLeast(0L)
                    if (len > 0) t = t.coerceAtMost(len - 500)
                    hTarget = t; hSeeking = true
                    val d = (t - hStartPos) / 1000
                    flash((if (d >= 0) "+" else "−") + abs(d) + " ثانیه  ·  " + fmt(t))
                    return true
                }
                val frac = dy / root.height.toFloat()
                if (e1.x < root.width / 2f) changeBrightness(frac) else changeVolume(frac)
                return true
            }
        })
        val sg = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean {
                pinchSub = !locked && inSubZone(d.focusX, d.focusY)
                subDragCand = false
                return true
            }
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                if (locked) return true
                if (pinchSub) {
                    subSize = (subSize * d.scaleFactor).coerceIn(0.03f, 0.12f)
                    applySubStyle()
                    flash("اندازه‌ی زیرنویس " + (subSize * 1000).toInt())
                    return true
                }
                zoomAnim?.cancel()
                zoom = (zoom * d.scaleFactor).coerceIn(0.5f, 4f)
                if (zoom <= 1f) { panX = 0f; panY = 0f }
                applyZoom()
                return true
            }
            override fun onScaleEnd(d: android.view.ScaleGestureDetector) {
                if (pinchSub) {
                    getSharedPreferences("player", MODE_PRIVATE).edit().putFloat("sub_size", subSize).apply()
                    flash("اندازه‌ی زیرنویس ذخیره شد")
                    pinchSub = false
                } else if (zoom < 1f || (zoom != 1f && Math.abs(zoom - 1f) < 0.1f)) {
                    animateZoomTo(1f)
                }
            }
        })
        root.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    subDragging = false
                    subDragCand = !locked && inSubZone(ev.x, ev.y)
                    subStartY = ev.y; subStartBottom = subBottom
                }
                MotionEvent.ACTION_POINTER_DOWN -> subDragCand = false
                MotionEvent.ACTION_MOVE -> if (subDragCand && ev.pointerCount == 1 && !sg.isInProgress) {
                    val dy = ev.y - subStartY
                    if (!subDragging && abs(dy) > dp(8)) {
                        subDragging = true
                        val c = MotionEvent.obtain(ev); c.action = MotionEvent.ACTION_CANCEL; gd.onTouchEvent(c); c.recycle()
                    }
                    if (subDragging) {
                        subBottom = (subStartBottom - dy / root.height.toFloat()).coerceIn(0f, 0.7f)
                        applySubStyle()
                    }
                }
            }
            sg.onTouchEvent(ev)
            if (!sg.isInProgress && !subDragging) gd.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (hSeeking && ev.actionMasked == MotionEvent.ACTION_UP) { engine?.time = hTarget; lastPos = hTarget }
                hSeeking = false; scrollMode = 0
                if (subDragging) {
                    getSharedPreferences("player", MODE_PRIVATE).edit().putFloat("sub_bottom", subBottom).apply()
                    flash("موقعیت زیرنویس ذخیره شد")
                }
                subDragging = false; subDragCand = false
                stopRewind()
                if (boost) {
                    boost = false
                    engine?.setRate(speeds[speedIdx])
                    toast.visibility = View.GONE
                }
            }
            true
        }
        updateVolFromSystem()
    }

    // ---------------------------------------------------------------- زوم و قفل
    private fun applyZoom() {
        val maxX = (root.width * (zoom - 1f)) / 2f
        val maxY = (root.height * (zoom - 1f)) / 2f
        val mx = maxX.coerceAtLeast(0f); val my = maxY.coerceAtLeast(0f)
        panX = panX.coerceIn(-mx, mx); panY = panY.coerceIn(-my, my)
        exoView.scaleX = zoom; exoView.scaleY = zoom
        exoView.translationX = panX; exoView.translationY = panY
        zoomText.text = (zoom * 100).toInt().toString() + "٪"
        zoomPill.visibility = if (Math.abs(zoom - 1f) > 0.02f) View.VISIBLE else View.GONE
    }

    private var zoomAnim: android.animation.ValueAnimator? = null
    private var rewinding = false
    private var rwWasPlaying = false
    private val rwTick = object : Runnable {
        override fun run() {
            if (!rewinding) return
            val mp = engine ?: return
            if (mp.time <= 0L) { stopRewind(); return }
            seekBy(-500)
            flash("◀◀  عقب ۲x  ·  " + fmt(mp.time))
            ui.postDelayed(this, 250)
        }
    }
    private fun stopRewind() {
        if (!rewinding) return
        rewinding = false
        ui.removeCallbacks(rwTick)
        if (rwWasPlaying) engine?.play()
        toast.visibility = View.GONE
    }
    private var scrollMode = 0      // 0 نامشخص، 1 عمودی، 2 افقی
    private var hSeeking = false
    private var hStartPos = 0L
    private var hTarget = 0L

    // برگشت نرم به اندازه‌ی اصلی (مثل MX Player): با رها کردن انگشت زیر ۱۰۰٪ یا نزدیک ۱۰۰٪ می‌چسبد
    private fun animateZoomTo(target: Float) {
        zoomAnim?.cancel()
        val z0 = zoom; val x0 = panX; val y0 = panY
        val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
        a.duration = 200
        a.interpolator = android.view.animation.DecelerateInterpolator(1.6f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            zoom = z0 + (target - z0) * f
            val k = if (target <= 1f) 1f - f else 1f
            panX = x0 * k; panY = y0 * k
            applyZoom()
        }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: android.animation.Animator) { if (target == 1f) { zoom = 1f; panX = 0f; panY = 0f; applyZoom() } }
        })
        zoomAnim = a
        a.start()
        try { root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK) } catch (e: Throwable) { }
    }

    private fun resetZoom() { zoomAnim?.cancel(); animateZoomTo(1f) }

    private fun setLocked(v: Boolean) {
        locked = v
        if (v) {
            setControls(false)
            showUnlockTemporarily()
            flash("صفحه قفل شد")
        } else {
            unlockBtn.visibility = View.GONE
            setControls(true)
            flash("قفل باز شد")
        }
    }

    private val hideUnlock = Runnable { if (locked) unlockBtn.visibility = View.GONE }
    private fun showUnlockTemporarily() {
        unlockBtn.visibility = View.VISIBLE
        ui.removeCallbacks(hideUnlock)
        ui.postDelayed(hideUnlock, 2500)
    }

    private fun onBackTap() {
        if (locked) { showUnlockTemporarily(); flash("برای خروج اول قفل را باز کن"); return }
        finish()
    }

    override fun onBackPressed() {
        if (nextCard.visibility == View.VISIBLE) { cancelNext(); finish(); return }
        if (locked) { showUnlockTemporarily(); flash("برای خروج اول قفل را باز کن"); return }
        super.onBackPressed()
    }

    private fun updateVolIcon(frac: Float) {
        volIcon.set(*(if (frac <= 0.01f) arrayOf(IconView.VOL1, IconView.MUTE2) else arrayOf(IconView.VOL1, IconView.VOL2)))
    }

    private fun updateVolFromSystem() {
        if (volSeek.isDragging()) return
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val f = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
        volSeek.setProgress(f)
        updateVolIcon(f)
    }

    private var preMuteVol = -1
    private fun toggleMute() {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        if (cur > 0) { preMuteVol = cur; audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0) }
        else audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, if (preMuteVol > 0) preMuteVol else max / 2, 0)
        updateVolFromSystem()
    }

    // بلور جعبه‌ای سه‌گذره روی بیت‌مپ کوچک (نرم و سبک)
    private fun boxBlur(src: Bitmap, r: Int, passes: Int): Bitmap {
        val w = src.width; val h = src.height
        var a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h)
        var b = IntArray(w * h)
        fun pass(inp: IntArray, out: IntArray, horiz: Boolean) {
            val n = if (horiz) w else h; val lines = if (horiz) h else w
            for (l in 0 until lines) {
                for (i in 0 until n) {
                    var sr = 0; var sg = 0; var sb = 0; var cnt = 0
                    for (k in -r..r) {
                        val j = (i + k).coerceIn(0, n - 1)
                        val px = if (horiz) inp[l * w + j] else inp[j * w + l]
                        sr += (px shr 16) and 255; sg += (px shr 8) and 255; sb += px and 255; cnt++
                    }
                    val o = (0xFF shl 24) or ((sr / cnt) shl 16) or ((sg / cnt) shl 8) or (sb / cnt)
                    if (horiz) out[l * w + i] = o else out[i * w + l] = o
                }
            }
        }
        repeat(passes) { pass(a, b, true); pass(b, a, false) }
        val res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        res.setPixels(a, 0, w, 0, 0, w, h)
        return res
    }

    private fun hideLoader() {
        if (loaderGone) return
        loaderGone = true
        (loader.tag as? android.animation.Animator)?.cancel()
        loader.animate().alpha(0f).setDuration(220).withEndAction { loader.visibility = View.GONE }.start()
    }

    private var lastPlayingUi: Boolean? = null
    private fun setPlayingUi(playing: Boolean) {
        playIconBig.set(if (playing) IconView.PAUSE else IconView.PLAY)
        playIconMini.set(if (playing) IconView.PAUSE else IconView.PLAY)
        if (lastPlayingUi != null && lastPlayingUi != playing) {
            // تعویض آیکن مثل وب: کوچک + چرخیده → اندازه‌ی کامل با کمی ارتجاع
            for (v in arrayOf<View>(playIconBig, playIconMini)) {
                v.animate().cancel()
                v.scaleX = 0.3f; v.scaleY = 0.3f; v.alpha = 0f; v.rotation = if (playing) -70f else 70f
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).rotation(0f).setDuration(320)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.5f)).start()
            }
        }
        lastPlayingUi = playing
    }

    // حلقه‌ی پخش‌شونده دور دکمه (ringOut وب): ۰٫۷× → ۱٫۵۵× و محو
    private fun ring(btn: View) {
        try {
            val a = IntArray(2); val b = IntArray(2)
            btn.getLocationInWindow(a); root.getLocationInWindow(b)
            val r = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Color.TRANSPARENT)
            g.setStroke(dp(2), Color.argb(180, 255, 255, 255))
            r.background = g
            val lp = FrameLayout.LayoutParams(btn.width, btn.height, Gravity.TOP or Gravity.LEFT)
            lp.leftMargin = a[0] - b[0]; lp.topMargin = a[1] - b[1]
            root.addView(r, lp)
            r.scaleX = 0.7f; r.scaleY = 0.7f; r.alpha = 0.9f
            r.animate().scaleX(1.55f).scaleY(1.55f).alpha(0f).setDuration(550)
                .withEndAction { root.removeView(r) }.start()
        } catch (e: Throwable) { }
    }

    // چرخش کامل آیکن ±۱۰ (rwSpin/fwSpin وب)
    private fun spin(v: View, deg: Float) {
        v.animate().cancel()
        v.rotation = 0f
        v.animate().rotation(deg).setDuration(500).setInterpolator(android.view.animation.OvershootInterpolator(1.2f))
            .withEndAction { v.rotation = 0f }.start()
    }

    private fun refreshQualityLabel() {
        val o = variants.optJSONObject(curVariant)
        val q = o?.optString("q") ?: ""
        qualityLabel.text = if (q.isNotEmpty()) q else "--"
        speedLabel.text = fmtSpeed(speeds[speedIdx]) + "x"
    }

    private fun fmtSpeed(v: Float): String = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()

    private fun applySubStyle() {
        try {
            exoView.subtitleView?.setFractionalTextSize(subSize)
            exoView.subtitleView?.setBottomPaddingFraction(subBottom)
        } catch (e: Throwable) { }
    }

    // ---------------------------------------------------------------- برگه‌های پایین (مثل popup_sheet وب)
    private class Row(val label: String, val sub: String = "", val active: Boolean = false, val onClick: () -> Unit)

    private fun openSheet(title: String, rows: List<Row>) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val bg = GradientDrawable()
        bg.setColor(Color.argb(238, 18, 20, 28))
        val r = dp(18).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        bg.setStroke(dp(1), Color.argb(31, 255, 255, 255))
        sheet.background = bg

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(18), dp(12), dp(18), dp(12))
        val tt = TextView(this); tt.text = title; tt.setTextColor(Color.WHITE); tt.textSize = 14f; tt.typeface = Typeface.DEFAULT_BOLD
        head.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
        val close = glassCircle(30, Color.argb(46, 255, 255, 255), Color.argb(46, 255, 255, 255))
        close.addView(icon(IconView.CLOSE, sizeDp = 14))
        close.setOnClickListener { dlg.dismiss() }
        head.addView(close, LinearLayout.LayoutParams(dp(30), dp(30)))
        sheet.addView(head)
        val line = View(this); line.setBackgroundColor(Color.argb(31, 255, 255, 255))
        sheet.addView(line, LinearLayout.LayoutParams(-1, dp(1)))

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(10), dp(8), dp(10), dp(10))
        for (row in rows) {
            val item = LinearLayout(this)
            item.gravity = Gravity.CENTER_VERTICAL
            item.setPadding(dp(12), dp(12), dp(12), dp(12))
            if (row.active) {
                val g = GradientDrawable(); g.setColor(Color.argb(46, 51, 144, 236)); g.cornerRadius = dp(10).toFloat(); g.setStroke(dp(1), Color.argb(77, 120, 190, 255))
                item.background = g
            }
            val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
            val t = TextView(this); t.text = row.label; t.textSize = 13.5f
            t.setTextColor(if (row.active) Ui.ACCENT else Color.WHITE)
            if (row.active) t.typeface = Typeface.DEFAULT_BOLD
            col.addView(t)
            if (row.sub.isNotEmpty()) {
                val st = TextView(this); st.text = row.sub; st.textSize = 11f; st.setTextColor(Color.argb(150, 255, 255, 255)); col.addView(st)
            }
            item.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (row.active) item.addView(icon(IconView.CHECK, sizeDp = 18).also { it.tint = Ui.ACCENT; it.layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)) })
            item.setOnClickListener { dlg.dismiss(); row.onClick() }
            list.addView(item, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(2) })
        }
        val sv = android.widget.ScrollView(this)
        sv.addView(list)
        val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
        sheet.addView(sv, LinearLayout.LayoutParams(-1, -2))
        sheet.measure(View.MeasureSpec.makeMeasureSpec(dp(480), View.MeasureSpec.AT_MOST), View.MeasureSpec.UNSPECIFIED)
        if (sheet.measuredHeight > maxH) sv.layoutParams = LinearLayout.LayoutParams(-1, maxH - dp(52))
        dlg.setContentView(sheet)
        dlg.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.BOTTOM)
            setLayout(Math.min(resources.displayMetrics.widthPixels, dp(480)), WindowManager.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.38f)
            decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
        dlg.setOnDismissListener { hideSystemBars() }
        ui.removeCallbacks(hideTask)
        dlg.show()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun setControls(show: Boolean) {
        controlsShown = show
        controls.animate().cancel()
        if (show) {
            controls.visibility = View.VISIBLE
            controls.animate().alpha(1f).setDuration(220).start()
            scheduleHide()
        } else {
            controls.animate().alpha(0f).setDuration(220).withEndAction { if (!controlsShown) controls.visibility = View.INVISIBLE }.start()
        }
    }

    private fun scheduleHide() {
        ui.removeCallbacks(hideTask)
        if (controlsShown && !dragging && engine?.isPlaying == true) ui.postDelayed(hideTask, 4000)
    }

    private fun flash(text: String) {
        toast.textDirection = View.TEXT_DIRECTION_LTR
        toast.text = text
        toast.visibility = View.VISIBLE
        ui.removeCallbacks(toastTask)
        ui.postDelayed(toastTask, 800)
    }

    private fun showToast(text: String) = flash(text)

    // نمایش کنار صفحه مثل وب: «+۱۰ ثانیه» سمت راست، «−۱۰ ثانیه» سمت چپ
    private fun seekFlash(right: Boolean) {
        var v = if (right) sfRight else sfLeft
        if (v == null) {
            v = TextView(this)
            v.textDirection = View.TEXT_DIRECTION_LTR
            v.gravity = Gravity.CENTER
            v.setTextColor(Color.WHITE)
            v.textSize = 13f
            v.typeface = Typeface.DEFAULT_BOLD
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(Color.argb(110, 0, 0, 0))
            v.background = bg
            v.alpha = 0f
            val lp = FrameLayout.LayoutParams(dp(92), dp(92), Gravity.CENTER_VERTICAL or (if (right) Gravity.RIGHT else Gravity.LEFT))
            lp.setMargins(dp(70), 0, dp(70), 0)
            root.addView(v, lp)
            if (right) sfRight = v else sfLeft = v
        }
        v.text = if (right) "▶▶\n+۱۰\nثانیه" else "◀◀\n−۱۰\nثانیه"
        v.animate().cancel()
        v.alpha = 1f
        v.animate().alpha(0f).setStartDelay(380).setDuration(260).start()
    }

    // ناحیه‌ی زیرنویس (برای کشیدن بالا/پایین و پینچ اندازه)
    private fun inSubZone(x: Float, y: Float): Boolean {
        if (!cueOn) return false
        val h = root.height.toFloat(); val w = root.width.toFloat()
        val base = h * (1f - subBottom)
        return y in (base - h * 0.22f)..(base + h * 0.04f) && x in (w * 0.1f)..(w * 0.9f)
    }

    // ------------------------------------------------------------ playback
    private fun togglePlay() {
        val mp = engine ?: return
        if (mp.isPlaying) { userPaused = true; mp.pause() } else { userPaused = false; mp.play() }
    }

    private fun seekBy(deltaMs: Long) {
        val mp = engine ?: return
        val len = mp.length
        var t = mp.time + deltaMs
        if (t < 0) t = 0
        if (len > 0 && t > len - 500) t = len - 500
        mp.time = t
    }

    private fun changeBrightness(frac: Float) {
        val lp = window.attributes
        var b = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
        b = (b + frac).coerceIn(0.02f, 1f)
        lp.screenBrightness = b
        window.attributes = lp
        flash("روشنایی  " + (b * 100).toInt() + "٪")
    }

    private fun changeVolume(frac: Float) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val nv = (cur + frac * max * 1.4f).toInt().coerceIn(0, max)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nv, 0)
        flash("صدا  " + (nv * 100 / max) + "٪")
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    // ------------------------------------------------------ engine events
    override fun onPlaying() {
        ui.post {
            hideLoader()
            spinner.visibility = View.GONE
            setPlayingUi(true)
            scheduleHide()
        }
    }
    override fun onPaused() { ui.post { setPlayingUi(false); ui.removeCallbacks(hideTask) } }
    override fun onBuffering(buffering: Boolean) { ui.post { spinner.visibility = if (buffering) View.VISIBLE else View.GONE } }
    override fun onLength(ms: Long) { ui.post { lastLen = ms; totView.text = fmt(ms) } }
    override fun onTime(ms: Long) {
        ui.post {
            lastPos = ms
            val nowT = System.currentTimeMillis()
            if (nowT - lastSaveAt > 10_000) { lastSaveAt = nowT; saveLocalPos() }
            updateSkip()
            if (!dragging) {
                curView.text = fmt(lastPos)
                if (lastLen > 0) {
                    seek.setProgress(lastPos.toFloat() / lastLen)
                    seek.buffer = (engine?.buffered ?: 0L).toFloat() / lastLen
                }
                updateVolFromSystem()
            }
        }
    }
    override fun onEnded() {
        ui.post {
            if (hasNext && !noNext && epChip.isNotEmpty()) startNextCountdown()
            else { ended = true; finish() }
        }
    }
    override fun onError(msg: String) {
        ui.post {
            errorMsg = "پخش این فایل ممکن نشد (" + msg + ")"
            spinner.visibility = View.GONE
            showToast("خطا در پخش؛ اتصال یا فایل را بررسی کنید")
            ui.postDelayed({ finish() }, 2200)
        }
    }

    override fun onCues(visible: Boolean) { cueOn = visible }

    // ذخیره‌ی موقعیت روی خود گوشی (بدون نیاز به سرور)
    private fun saveLocalPos() {
        if (resumeKey.isEmpty() || ended) return
        val e = getSharedPreferences("player", MODE_PRIVATE).edit()
        if (lastPos < 5000 || (lastLen > 0 && lastPos > lastLen * 0.95)) e.remove(resumeKey) else e.putLong(resumeKey, lastPos)
        e.apply()
    }

    // «رد کردن تیتراژ»: فقط برای سریال، در ۴ دقیقه‌ی اول
    private fun updateSkip() {
        if (epChip.isEmpty() || skipDone || locked) { if (skipBtn.visibility != View.GONE) skipBtn.visibility = View.GONE; return }
        val show = lastPos in 3_000L..240_000L && nextCard.visibility != View.VISIBLE
        val v = if (show) View.VISIBLE else View.GONE
        if (skipBtn.visibility != v) skipBtn.visibility = v
    }

    private val nextTick = object : Runnable {
        override fun run() {
            if (nextCard.visibility != View.VISIBLE) return
            if (nextLeft <= 0) { ended = true; finish(); return }
            nextTxt.text = "قسمت بعدی تا " + nextLeft + " ثانیه دیگر"
            nextLeft--
            ui.postDelayed(this, 1000)
        }
    }

    private fun startNextCountdown() {
        nextLeft = 8
        skipBtn.visibility = View.GONE
        setControls(false)
        nextCard.visibility = View.VISIBLE
        ui.post(nextTick)
    }

    private fun cancelNext() {
        noNext = true
        ui.removeCallbacks(nextTick)
        nextCard.visibility = View.GONE
        setControls(true)
    }

    override fun onLog(line: String) {
        val t = String.format(java.util.Locale.US, "%7.2f ", (android.os.SystemClock.elapsedRealtime() - t0) / 1000.0)
        android.util.Log.d("CloudPlayer", line)
        synchronized(logBuf) { logBuf.addLast(t + line); while (logBuf.size > 1500) logBuf.removeFirst() }
    }

    override fun onTracksReady() {
        ui.post {
            if (engine?.hasUnsupportedOnly() == true) showToast("صدای این فایل روی گوشی پشتیبانی نمی‌شود")
        }
    }

    private fun showLog() {
        val all = synchronized(logBuf) { logBuf.joinToString("\n") }
        val tv = TextView(this)
        tv.text = all.split("\n").takeLast(250).joinToString("\n")
        tv.setTextIsSelectable(true)
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 10f
        tv.setPadding(dp(12), dp(12), dp(12), dp(12))
        val sv = android.widget.ScrollView(this)
        sv.addView(tv)
        AlertDialog.Builder(this).setTitle("لاگ پخش")
            .setView(sv)
            .setPositiveButton("کپی") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("player log", all))
                showToast("لاگ کپی شد")
            }
            .setNegativeButton("بستن", null).show()
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }

    // ------------------------------------------------------------- منوها
    private fun isDubIdx(i: Int) = variants.optJSONObject(i)?.optBoolean("dub", false) ?: false
    private fun qOf(i: Int) = variants.optJSONObject(i)?.optString("q") ?: ""

    // اسم ترک صدا را تمیز می‌کند: «Film2Media - Namava · Persian · mp4a-latm · 2ch» → «Namava · فارسی»
    private fun cleanAudio(raw: String): Triple<String, Boolean, String> {
        var s = raw.replace(Regex("(?i)film2media\\s*[-–:]*\\s*"), "").replace(" (پشتیبانی نمی‌شود)", "")
        val parts = s.split("·").map { it.trim() }.filter { it.isNotEmpty() }.filter {
            !Regex("(?i)^(mp4a.*|ac-?3|e-?ac-?3|aac.*|opus|dts.*|mp3|flac|vorbis|truehd|\\d(\\.\\d)?ch|audio.*)$").matches(it)
        }
        var fa = false
        var lang = ""
        val out = parts.map {
            when {
                it.equals("persian", true) || it.equals("farsi", true) || it.equals("fas", true) || it.equals("fa", true) || it.equals("per", true) -> { fa = true; lang = "fa"; "فارسی" }
                it.equals("english", true) || it.equals("eng", true) || it.equals("en", true) -> { lang = "en"; "انگلیسی" }
                else -> it
            }
        }
        if (lang.isEmpty()) lang = out.lastOrNull() ?: "?"
        val lbl = if (out.isEmpty()) raw else out.joinToString(" · ")
        return Triple(lbl, fa, lang)
    }

    private fun pickAudio() {
        val mp = engine ?: return
        val rows = ArrayList<Row>()
        // فایل‌های همین قسمت با کیفیت فعلی (دوبله / زیرنویس)
        val curQ = qOf(curVariant)
        val seen = HashSet<Boolean>()
        for (i in 0 until variants.length()) {
            val o = variants.optJSONObject(i) ?: continue
            if (curQ.isNotEmpty() && qOf(i) != curQ) continue
            val idx = i
            seen.add(isDubIdx(i))
            rows.add(Row((if (isDubIdx(i)) "دوبله فارسی" else "اصلی / زیرنویس"), "فایل" + (if (curQ.isNotEmpty()) " · $curQ" else ""), idx == curVariant) { if (idx != curVariant) switchVariant(idx) })
        }
        // ترک‌های صدای داخل فایل
        val tr = mp.audioTracks()
        val seenLbl = HashSet<String>()
        val seenLang = HashSet<String>()
        for (t in tr) {
            val c = cleanAudio(t.name)
            val fa = c.second
            // فارسی‌ها همه (با اسم استودیو)، بقیه‌ی زبان‌ها فقط یکی؛ ترک انتخاب‌شده همیشه می‌ماند
            if (!t.selected) {
                if (!fa && !seenLang.add(c.third)) continue
            } else seenLang.add(c.third)
            if (!seenLbl.add(c.first)) { if (!t.selected) continue }
            rows.add(Row(c.first, "ترک صدا", t.selected) { mp.setAudio(t.id); flash(c.first) })
        }
        if (rows.isEmpty()) { flash("صدایی یافت نشد"); return }
        openSheet("صدا / دوبله", rows)
    }

    private fun pickQuality() {
        val rows = ArrayList<Row>()
        val dub = isDubIdx(curVariant)
        for (i in 0 until variants.length()) {
            if (isDubIdx(i) != dub) continue
            val idx = i
            val q = qOf(i)
            rows.add(Row(if (q.isNotEmpty()) q else "فایل " + (i + 1), variants.optJSONObject(i)?.optString("label") ?: "", idx == curVariant) { if (idx != curVariant) switchVariant(idx) })
        }
        if (rows.isEmpty()) { flash("کیفیت دیگری نیست"); return }
        openSheet("کیفیت", rows)
    }

    // عوض‌کردن فایل (دوبله ↔ زیرنویس یا کیفیت دیگر) از همان نقطه‌ی فعلی
    private fun switchVariant(idx: Int) {
        val o = variants.optJSONObject(idx) ?: return
        val u = o.optString("url")
        if (u.isEmpty()) return
        curVariant = idx
        mediaUrl = u
        val sub = o.optString("sub")
        val sj = JSONArray()
        if (sub.isNotEmpty()) sj.put(org.json.JSONObject().put("url", sub).put("label", "زیرنویس"))
        subs = sj
        spinner.visibility = View.VISIBLE
        refreshQualityLabel()
        showToast(o.optString("label"))
        engine?.load(u, mediaReferer, lastPos, subs)
    }

    private fun pickSubtitle() {
        val mp = engine ?: return
        val tr = mp.subTracks()
        openSheet("زیرنویس", tr.map { t -> Row(t.name, "", t.selected) { mp.setSub(t.id) } })
    }

    private fun pickSpeed() {
        val mp = engine ?: return
        openSheet("سرعت پخش", speeds.indices.map { i ->
            Row(fmtSpeed(speeds[i]) + "x" + (if (speeds[i] == 1f) "  (عادی)" else ""), "", i == speedIdx) { speedIdx = i; getSharedPreferences("player", MODE_PRIVATE).edit().putInt("speed", i).apply(); mp.setRate(speeds[i]); speedLabel.text = fmtSpeed(speeds[i]) + "x" }
        })
    }

    private val scaleLabels = arrayOf("متناسب با صفحه", "کشیده (پر کردن)", "برش‌خورده (زوم)")
    private fun cycleScale() {
        scaleIdx = (scaleIdx + 1) % scaleLabels.size
        engine?.setScale(scaleIdx)
        getSharedPreferences("player", MODE_PRIVATE).edit().putInt("scale", scaleIdx).apply()
        flash(scaleLabels[scaleIdx])
    }

    private fun openSettings() {
        val pf = getSharedPreferences("player", MODE_PRIVATE)
        val sizes = floatArrayOf(0.04f, 0.055f, 0.07f, 0.09f)
        val sizeNames = arrayOf("کوچک", "متوسط", "بزرگ", "خیلی بزرگ")
        val si = sizes.indexOfFirst { Math.abs(it - subSize) < 0.004f }.let { if (it < 0) 1 else it }
        val bottoms = floatArrayOf(0.04f, 0.08f, 0.14f, 0.2f)
        val bottomNames = arrayOf("پایین", "پیش‌فرض", "بالاتر", "خیلی بالا")
        val bi = bottoms.indexOfFirst { Math.abs(it - subBottom) < 0.01f }.let { if (it < 0) 1 else it }
        openSheet("تنظیمات", listOf(
            Row("اندازه‌ی زیرنویس", sizeNames[si]) {
                val n = (si + 1) % sizes.size; subSize = sizes[n]; pf.edit().putFloat("sub_size", subSize).apply(); applySubStyle(); flash("اندازه: " + sizeNames[n])
            },
            Row("موقعیت زیرنویس", bottomNames[bi]) {
                val n = (bi + 1) % bottoms.size; subBottom = bottoms[n]; pf.edit().putFloat("sub_bottom", subBottom).apply(); applySubStyle(); flash("موقعیت: " + bottomNames[n])
            },
            Row("نمایش تصویر", scaleLabels[scaleIdx]) { cycleScale() },
            Row("بازنشانی زوم", if (zoom > 1.02f) (zoom * 100).toInt().toString() + "٪" else "۱۰۰٪") { resetZoom() },
            Row("لاگ پخش", "برای گزارش مشکل") { showLog() }
        ))
    }

    // -------------------------------------------------------- lifecycle
    override fun finish() {
        val data = Intent()
        val endNow = ended && !noNext
        if (endNow) getSharedPreferences("player", MODE_PRIVATE).edit().remove(resumeKey).apply() else saveLocalPos()
        data.putExtra("position", if (endNow) 0L else lastPos)
        data.putExtra("duration", lastLen)
        data.putExtra("ended", endNow)
        data.putExtra("error", errorMsg)
        setResult(RESULT_OK, data)
        super.finish()
    }

    private fun inPip(): Boolean =
        Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode

    // تصویر در تصویر: وقتی کاربر دکمه‌ی خانه را می‌زند پخش ادامه پیدا می‌کند
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        try {
            if (Build.VERSION.SDK_INT >= 26 && engine?.isPlaying == true && !isFinishing) {
                enterPictureInPictureMode(
                    android.app.PictureInPictureParams.Builder()
                        .setAspectRatio(android.util.Rational(16, 9)).build()
                )
            }
        } catch (e: Throwable) { }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            controls.visibility = View.GONE
        } else {
            controls.visibility = View.VISIBLE
            controls.alpha = 1f
            hideSystemBars()
            scheduleHide()
        }
    }

    override fun onPause() {
        try { saveLocalPos() } catch (e: Throwable) { }
        super.onPause()
        if (!isFinishing && !inPip()) engine?.pause()
    }

    override fun onStop() {
        super.onStop()
        // بستن پنجره‌ی PiP با ضربدر: صدا در پس‌زمینه نماند
        if (inPip() && !isFinishing) { try { engine?.pause() } catch (e: Throwable) { }; finish() }
    }

    override fun onDestroy() {
        active = false
        try { (loader.tag as? android.animation.Animator)?.cancel() } catch (e: Throwable) { }

        ui.removeCallbacksAndMessages(null)
        try { engine?.release() } catch (e: Throwable) { }
        engine = null
        super.onDestroy()
    }
}
