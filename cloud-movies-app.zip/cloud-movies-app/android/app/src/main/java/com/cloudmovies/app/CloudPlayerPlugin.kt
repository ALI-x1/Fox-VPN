package com.cloudmovies.app

import android.content.Intent
import androidx.activity.result.ActivityResult
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * پل بین صفحه‌ی وب (مینی‌اپ) و پلیر بومی ExoPlayer.
 * از جاوااسکریپت:  Capacitor.Plugins.CloudPlayer.play({ url, title, position, subtitles })
 */
@CapacitorPlugin(name = "CloudPlayer")
class CloudPlayerPlugin : Plugin() {

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        val ret = JSObject()
        ret.put("available", true)
        call.resolve(ret)
    }

    @PluginMethod
    fun play(call: PluginCall) {
        val url = call.getString("url")
        if (url.isNullOrBlank()) {
            call.reject("url لازم است")
            return
        }
        val intent = Intent(context, PlayerActivity::class.java)
        intent.putExtra("url", url)
        intent.putExtra("title", call.getString("title") ?: "")
        intent.putExtra("position", (call.getDouble("position") ?: 0.0).toLong())
        intent.putExtra("referer", call.getString("referer") ?: "")
        intent.putExtra("year", call.getString("year") ?: "")
        intent.putExtra("ep", call.getString("ep") ?: "")
        intent.putExtra("hasNext", call.getBoolean("hasNext") ?: false)
        intent.putExtra("poster", call.getString("poster") ?: "")
        // فایل‌های دیگر همین قسمت (دوبله/اصلی/کیفیت): [{url,label,sub}]
        intent.putExtra("variants", call.getArray("variants")?.toString() ?: "[]")
        // زیرنویس‌ها: [{url,label}] به‌صورت رشته‌ی JSON
        val subs = call.getArray("subtitles")
        intent.putExtra("subs", subs?.toString() ?: "[]")
        startActivityForResult(call, intent, "playerResult")
    }

    @ActivityCallback
    private fun playerResult(call: PluginCall?, result: ActivityResult) {
        if (call == null) return
        val data = result.data
        val ret = JSObject()
        ret.put("position", (data?.getLongExtra("position", 0L) ?: 0L).toDouble())
        ret.put("duration", (data?.getLongExtra("duration", 0L) ?: 0L).toDouble())
        ret.put("ended", data?.getBooleanExtra("ended", false) ?: false)
        ret.put("error", data?.getStringExtra("error") ?: "")
        call.resolve(ret)
    }
}
