package com.cloudmovies.app

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Collections

/**
 * کش پاسخ‌های عمومی سایت روی گوشی (stale-while-revalidate):
 * تازه (کمتر از ۲۰ دقیقه) → مستقیم از گوشی؛ کهنه‌ی مجاز (تا ۱۲ ساعت) → از گوشی + تازه‌سازی در پس‌زمینه؛
 * وگرنه از شبکه. فقط GETهای عمومی؛ چیزهای شخصی (me/favs/share) و لینک‌های پخش هیچ‌وقت کش نمی‌شوند.
 */
object ApiCache {
    private val paths = setOf(
        "/api/category", "/api/featured", "/api/genres", "/api/search", "/api/searchopts", "/api/cardinfo", "/api/cardinfos"
    )
    private const val FRESH = 20 * 60 * 1000L
    private const val STALE = 12 * 60 * 60 * 1000L
    private const val MAX_BYTES = 1_500_000
    private val busy: MutableSet<String> = Collections.synchronizedSet(HashSet())

    private fun key(url: String): String {
        val d = MessageDigest.getInstance("SHA-1").digest(url.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun handle(ctx: Context, req: WebResourceRequest): WebResourceResponse? {
        try {
            if (req.method != "GET") return null
            val u = req.url
            if (u.scheme != "https" || u.path !in paths) return null
            val url = u.toString()
            val dir = File(ctx.cacheDir, "api").also { it.mkdirs() }
            val k = key(url)
            val body = File(dir, "$k.b")
            val meta = File(dir, "$k.m")
            val now = System.currentTimeMillis()
            if (body.exists() && meta.exists()) {
                val lines = meta.readText().split("\n")
                val ts = lines.getOrNull(0)?.toLongOrNull() ?: 0L
                val mime = lines.getOrNull(1) ?: "application/json"
                val age = now - ts
                if (age < STALE) {
                    if (age >= FRESH && busy.add(k)) {
                        val hdr = HashMap(req.requestHeaders)
                        Thread { try { fetch(url, hdr, body, meta) } finally { busy.remove(k) } }.start()
                    }
                    return resp(mime, body.readBytes())
                }
            }
            val got = fetch(url, HashMap(req.requestHeaders), body, meta) ?: return null
            trim(dir)
            return resp(got.first, got.second)
        } catch (e: Throwable) {
            return null
        }
    }

    private fun fetch(url: String, hdr: Map<String, String>, body: File, meta: File): Pair<String, ByteArray>? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 20000
            for ((a, b) in hdr) if (!a.equals("Host", true) && !a.equals("Range", true)) c.setRequestProperty(a, b)
            CookieManager.getInstance().getCookie(url)?.let { c.setRequestProperty("Cookie", it) }
            if (c.responseCode != 200) return null
            val bytes = c.inputStream.use { it.readBytes() }
            if (bytes.isEmpty() || bytes.size > MAX_BYTES) return null
            val mime = (c.contentType ?: "application/json").substringBefore(';').trim()
            body.writeBytes(bytes)
            meta.writeText(System.currentTimeMillis().toString() + "\n" + mime)
            Pair(mime, bytes)
        } catch (e: Throwable) { null }
    }

    private fun resp(mime: String, bytes: ByteArray): WebResourceResponse {
        val r = WebResourceResponse(mime, "utf-8", ByteArrayInputStream(bytes))
        r.setStatusCodeAndReasonPhrase(200, "OK")
        r.responseHeaders = mapOf("Access-Control-Allow-Origin" to "*", "X-Cm-Cache" to "1")
        return r
    }

    private fun trim(dir: File) {
        val fs = dir.listFiles { f -> f.name.endsWith(".b") } ?: return
        if (fs.size <= 120) return
        fs.sortedBy { it.lastModified() }.take(fs.size - 100).forEach {
            it.delete(); File(dir, it.name.removeSuffix(".b") + ".m").delete()
        }
    }
}
